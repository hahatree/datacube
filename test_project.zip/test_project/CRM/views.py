from django.shortcuts import render
from .models import *
from django.http import HttpResponse

def mt5users(request):
    if request.method == 'GET':
        login_user = request.GET['login']
        print(login_user)
        data = Mt5Users.objects.get(login = login_user)
        data = data.toJSON()
        return HttpResponse(data, content_type="application/json")
